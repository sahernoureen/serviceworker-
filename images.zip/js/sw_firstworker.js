
  
  var CACHE_NAME = 'mycache_v4';
var filesToCache = [
  '/',
  '/images/kit1.jpg',
  '/images/kit2.jpg',
  '/images/kit3.jpg',
  '/html/contact.html',
  '/html/staff.html',
  '/html/aboutus.html',
  '/html/index.html',
  '/css/contact.css',
  '/css/index.css',
  '/css/normalize.css',
  '/css/test.css'

];

self.addEventListener('install', function(event) {
  console.log('Service worker is installed');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(function(cache) {
        console.log('Opened cache');
        return cache.addAll(filesToCache);
      })
  );
});

self.addEventListener("activate", e => {
  console.log("service worker is active");
  e.waitUntil(
    caches.keys().then(function(cacheNames) {
      return Promise.all(
        cacheNames
        .filter(function(cacheName) {
           if (cacheName != CACHE_NAME) return true;
         })
          .map(function(cacheName) {
            return caches.delete(cacheName);
          })
      );
    })
  );
});

self.addEventListener('fetch', event=>{
  console.log('fetch in portfolio proj is working');
  event.respondWith(
    caches.match(event.request).then(function(response) {
      return response || fetch(event.request);
    })
  );

});